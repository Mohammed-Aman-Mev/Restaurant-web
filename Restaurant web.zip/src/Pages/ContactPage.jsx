import React from "react";

const ContactPage = () => {
  return (
    <div>
      <h1 className="text-5xl pt-7 text-center">Contact page</h1>
    </div>
  );
};

export default ContactPage;
