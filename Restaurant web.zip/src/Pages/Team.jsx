import React from "react";

const Team = () => {
  return (
    <div>
      <h1 className="text-5xl pt-7 text-center">Team page</h1>
    </div>
  );
};

export default Team;
