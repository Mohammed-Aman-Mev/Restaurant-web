import React from 'react'

const Gallery = () => {
  return (
    <div>
      <h1 className="text-5xl pt-7 text-center">Gallery page</h1>
      
    </div>
  )
}

export default Gallery
