import React from "react";

const Gridcom2 = ({ img }) => {
  return (
    <div
      className="w-[100%] h-[346px] bg-center bg-no-repeat bg-cover"
      style={{
        backgroundImage: img,
      }}
    ></div>
  );
};

export default Gridcom2;
