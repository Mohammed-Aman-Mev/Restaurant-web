import React from "react";
import {
  BannerSection,
  Contactus,
  MealsSection,
  NewsandEvents,
  StorySection,
  Testimonial,
} from "../components";

const Landing = () => {
  return (
    <>
      <BannerSection />
      <StorySection />
      <MealsSection />
      <Testimonial />
      <NewsandEvents />
      <Contactus />
    </>
  );
};

export default Landing;
