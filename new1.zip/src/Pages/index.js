import Home from "./Home";
import Gallery from "./Gallery";
import ContactPage from "./ContactPage";
import Landing from "./Landing";
import Shop from "./Shop";
import Team from "./Team";
import Blog from "./Blog";
import About from "./About";
import ShopingCard from "./ShopingCard";

export { Home, Shop, Gallery, Landing, ContactPage, Team ,Blog,About,ShopingCard};
