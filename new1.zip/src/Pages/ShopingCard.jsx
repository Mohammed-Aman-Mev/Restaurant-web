import React from 'react'

const ShopingCard = () => {
  return (
    <div>
      Card
    </div>
  )
}

export default ShopingCard
