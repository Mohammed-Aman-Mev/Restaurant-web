import React from 'react'

const Team = () => {
  return (
    <div>
      team
    </div>
  )
}

export default Team
