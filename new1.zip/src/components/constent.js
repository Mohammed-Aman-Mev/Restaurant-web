
export const item = [
  { title: "Landing", path: "/" },
  { title: "Home", path: "/home" },
  { title: "Gallery", path: "/gallery" },
  { title: "Shop", path: "/shop" },
  { title: "Blog", path: "/blog" },
  { title: "About", path: "/about" },
  { title: "Team", path: "/team" },
  { title: "Contact", path: "/contact" },
];
