import React from "react";

const Contactus = () => {
  return <div>Contact us</div>;
};

export default Contactus;
