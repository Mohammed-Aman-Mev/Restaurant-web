import React from "react";

const NewsandEvents = () => {
  return <div>News and events</div>;
};

export default NewsandEvents;
