import React from "react";

const StorySection = () => {
  return (
    <>
      <div className="w-full p-[5%] font-sans">
        <div className="w-full h-[100vh] flex-wrap flex sm:p-7 md:flex-nowrap px-auto">
          <div className="w-full md:w-[50%] flex-col justify-between">
            <h3 className="text-yellow-600 text-[13px] font-bold">OUR STORY</h3>
            <div className="bg-yellow-600 w-[50px] h-[5px] mt-4" />
            <h2 className="mt-4 text-4xl">Welcome To Royal</h2>
            <p className="mt-4">
              Lorem ipsum dolor sit amet consectetur adipisicing elit.
              Consectetur quidem quo deserunt tenetur dolore adipisci quas et
              tempora illum cupiditate vel dolor sequi, eveniet, pariatur
              fugiat, nulla placeat eius ipsum?
            </p>
            <p className="mt-4">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit eos
              quasi sapiente sunt non ducimus ratione, officiis eum atque soluta
              tempora quis rem cum? Dolores a suscipit minima soluta Lorem ipsum
              do
            </p>
          </div>
          <div className="w-full md:w-50% p-8">
            <img
              src="https://media.istockphoto.com/id/1273378551/photo/set-of-summer-fruits-and-berries-in-wooden-serving.jpg?s=612x612&w=0&k=20&c=XtJFQDgpV_AsG3aFzo3FVN2pmbey7h0jWHMzlHWJ5Kk="
              alt=""
              className="w-[100%]"
            />
          </div>
        </div>
      </div>
      <div className="bg-slate-200 p-[20px]">
        <div className="flex-col justify-between">
          <h3 className="w-[150px] sm:w-[10%] mx-auto mt-5">ONLY THE BEST</h3>
          <div className="bg-yellow-600 h-1 w-[50px] mx-auto mt-1" />
          <h2 className="text-xl w-[25%] mx-auto mt-5">
            Fresh Ingredients, Tasty Maels
          </h2>
          <p className="w-[70%] mx-auto mt-5">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum
            repudiandae voluptatum similique at eos molestias vitae? Possimus
            sequi, voluptas molestias minus pariatur eligendi neque recusandae
            ratione maiores cupiditate molestiae quae!
          </p>
        </div>
        <div className="flex items-center mt-5">
          <button className="bg-yellow-600 text-sm text-white p-1.5 px-1.5 w-[100px] mx-auto">
            RESEVATION
          </button>
        </div>
      </div>
    </>
  );
};

export default StorySection;
