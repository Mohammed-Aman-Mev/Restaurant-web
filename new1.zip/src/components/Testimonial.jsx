import React from "react";

const Testimonial = () => {
  return <div>testimonial</div>;
};

export default Testimonial;
