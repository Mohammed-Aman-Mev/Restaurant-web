import React from "react";

const MealsSection = () => {
  return (
    <div className="px-[50px]">
      <div className="grid w-[100%] h-[400%] grid-cols-1 sm:grid-cols-2 md:grid-cols-3 mx-auto">
        <div className="w-[100%] h-[100%] flex-col items-center justify-center p-1 ">
          <h2 className="text-center">$250</h2>
          <h2 className="text-center">Lorem, ipsum</h2>
          <p className="text-center">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium
            ullam, voluptatum corrupti voluptatibus ipsam debitis?
          </p>
        </div>
        <div
          className="w-[100%] h-[350px] flex-col items-center p-1 bg-center bg-no-repeat bg-cover"
          style={{
            backgroundImage:
              "url(https://media.istockphoto.com/id/92367660/photo/fruit-basket.jpg?s=612x612&w=0&k=20&c=FGQ0K8Cp3lKtm2LPah8vcMb_1a45qTKLeldPk96M_HY=)",
          }}
        ></div>
        <div className="w-[100%] h-[100%] flex-col items-center justify-center p-1">
          <h2 className="text-center">$250</h2>
          <h2 className="text-center">Lorem, ipsum</h2>
          <p className="text-center">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium
            ullam, voluptatum corrupti voluptatibus ipsam debitis?
          </p>
        </div>
        <div
          className="w-[100%] h-[350px] flex-col items-center p-1 bg-center bg-no-repeat bg-cover"
          style={{
            backgroundImage:
              "url(https://media.istockphoto.com/id/92367660/photo/fruit-basket.jpg?s=612x612&w=0&k=20&c=FGQ0K8Cp3lKtm2LPah8vcMb_1a45qTKLeldPk96M_HY=)",
          }}
        ></div>
        <div className="w-[100%] h-[100%] flex-col items-center justify-center p-1">
          <h2 className="text-center">$250</h2>
          <h2 className="text-center">Lorem, ipsum</h2>
          <p className="text-center">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium
            ullam, voluptatum corrupti voluptatibus ipsam debitis?
          </p>
        </div>
        <div
          className="w-[100%] h-[350px] flex-col items-center p-1 bg-center bg-no-repeat bg-cover"
          style={{
            backgroundImage:
              "url(https://media.istockphoto.com/id/92367660/photo/fruit-basket.jpg?s=612x612&w=0&k=20&c=FGQ0K8Cp3lKtm2LPah8vcMb_1a45qTKLeldPk96M_HY=)",
          }}
        ></div>
        <div className="w-[100%] h-[100%] flex-col items-center justify-center p-1">
          <h2 className="text-center">$250</h2>
          <h2 className="text-center">Lorem, ipsum</h2>
          <p className="text-center">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium
            ullam, voluptatum corrupti voluptatibus ipsam debitis?
          </p>
        </div>
        <div
          className="w-[100%] h-[350px] flex-col items-center p-1 bg-center bg-no-repeat bg-cover"
          style={{
            backgroundImage:
              "url(https://media.istockphoto.com/id/92367660/photo/fruit-basket.jpg?s=612x612&w=0&k=20&c=FGQ0K8Cp3lKtm2LPah8vcMb_1a45qTKLeldPk96M_HY=)",
          }}
        ></div>
        <div className="w-[100%] h-[100%] flex-col items-center justify-center p-1">
          <h2 className="text-center">$250</h2>
          <h2 className="text-center">Lorem, ipsum</h2>
          <p className="text-center">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium
            ullam, voluptatum corrupti voluptatibus ipsam debitis?
          </p>
        </div>
        <div
          className="w-[100%] h-[350px] flex-col items-center p-1 bg-center bg-no-repeat bg-cover"
          style={{
            backgroundImage:
              "url(https://media.istockphoto.com/id/92367660/photo/fruit-basket.jpg?s=612x612&w=0&k=20&c=FGQ0K8Cp3lKtm2LPah8vcMb_1a45qTKLeldPk96M_HY=)",
          }}
        ></div>
        <div className="w-[100%] h-[100%] flex-col items-center justify-center p-1">
          <h2 className="text-center">$250</h2>
          <h2 className="text-center">Lorem, ipsum</h2>
          <p className="text-center">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium
            ullam, voluptatum corrupti voluptatibus ipsam debitis?
          </p>
        </div>
        <div
          className="w-[100%] h-[350px] flex-col items-center p-1 bg-center bg-no-repeat bg-cover"
          style={{
            backgroundImage:
              "url(https://media.istockphoto.com/id/92367660/photo/fruit-basket.jpg?s=612x612&w=0&k=20&c=FGQ0K8Cp3lKtm2LPah8vcMb_1a45qTKLeldPk96M_HY=)",
          }}
        ></div>
      </div>
    </div>
  );
};

export default MealsSection;
